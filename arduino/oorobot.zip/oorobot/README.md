# OoRoBoT: arduino firmware

This is the source code of the OoRoBoT firmware.

## How to build

- Get the the Arduino IDE (https://www.arduino.cc/en/Main/Software)
- Get the following libraries (using the Arduino IDE library manager)
	- **AccelStepper** v1.57.1 by Mike McCauley
	- **LiquidCrystal I2C** v1.1.2 by Frank de Brabander
- Open `oorobot.ino` in the IDE
- You're all set: hit the regular build/download buttons



#define KEYS_PIN A0

int getPressedButton();
void setupButtons();

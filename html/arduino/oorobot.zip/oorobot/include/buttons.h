

#define KEYS_PIN A0
#define KEYS_SCL_PIN A1
#define KEYS_SDO_PIN A2


char getPressedButton();
void setupButtons();
byte Read_Keypad();